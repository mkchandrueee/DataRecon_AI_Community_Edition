"""Server setup for DataRecon AI Community Edition.

Standard library only: these scripts run *before* the virtualenv exists, so they
cannot depend on anything the project installs. Run them from the repository
root with ``python -m deploy --help``.
"""
