# deploy/health.py — is it actually running, and is it set up safely?
from __future__ import annotations

import os
import stat
import subprocess
import time
import urllib.error
import urllib.request

from deploy.plan import DeployPlan, OperatingSystem, ServiceScope
from deploy.preflight import Check
from deploy.services import build_specs


def wait_for_http(url: str, timeout: float = 60.0, interval: float = 1.0) -> bool:
    """Poll until the URL answers 200, or the timeout passes.

    A service that has been *started* is not a service that is *serving*: the
    app takes several seconds to import its dependencies, so checking once
    straight after ``systemctl start`` reports a false failure.
    """
    deadline = time.monotonic() + timeout
    while True:
        if _answers(url):
            return True
        if time.monotonic() >= deadline:
            return False
        time.sleep(interval)


def _answers(url: str) -> bool:
    try:
        with urllib.request.urlopen(url, timeout=3) as response:  # fixed http URL
            return response.status == 200
    except (urllib.error.URLError, OSError):
        return False


def collect_status(plan: DeployPlan) -> list[Check]:
    checks = [
        Check("Virtualenv", plan.venv_python.exists(), str(plan.venv_python)),
        Check("Environment file", plan.env_file.is_file(), str(plan.env_file)),
        _env_permissions(plan),
        Check(
            "Metadata database", (plan.data_dir / "datarecon_meta.db").is_file(), str(plan.data_dir)
        ),
        _encryption_key(plan),
        *_service_checks(plan),
        Check("Web application", _answers(plan.health_url), plan.app_url, fatal=False),
    ]
    return checks


def _env_permissions(plan: DeployPlan) -> Check:
    if not plan.env_file.is_file():
        return Check("Environment file permissions", False, "file missing")
    if plan.os is OperatingSystem.WINDOWS:
        return Check(
            "Environment file permissions", True, "inherited from folder ACLs", fatal=False
        )
    mode = stat.S_IMODE(plan.env_file.stat().st_mode)
    return Check(
        "Environment file permissions",
        mode & (stat.S_IRWXG | stat.S_IRWXO) == 0,
        f"mode {mode:o} (should be 600 — it can hold the SMTP password)",
    )


def _encryption_key(plan: DeployPlan) -> Check:
    key = plan.data_dir / ".datarecon.key"
    return Check(
        "Encryption key",
        key.is_file(),
        f"{key} — back this up: without it stored connection passwords cannot be recovered",
    )


def _service_checks(plan: DeployPlan) -> list[Check]:
    if plan.os is not OperatingSystem.LINUX:
        return []
    base = ["systemctl"] if plan.scope is ServiceScope.SYSTEM else ["systemctl", "--user"]
    checks = []
    for spec in build_specs(plan):
        result = subprocess.run(  # fixed argv, no shell
            [*base, "is-active", f"{spec.name}.service"],
            capture_output=True,
            text=True,
            check=False,
        )
        state = result.stdout.strip() or "unknown"
        checks.append(Check(f"Service {spec.name}", state == "active", state))
    return checks


def privileged() -> bool:
    return hasattr(os, "geteuid") and os.geteuid() == 0
