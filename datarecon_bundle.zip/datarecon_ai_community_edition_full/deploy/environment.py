# deploy/environment.py — the virtualenv and the project's dependencies.
from __future__ import annotations

import logging
import sys

from deploy.plan import DeployPlan
from deploy.runner import Runner

logger = logging.getLogger("deploy")


def create_virtualenv(plan: DeployPlan, runner: Runner) -> None:
    """Create ``.venv`` unless it already holds a working interpreter.

    Idempotent on purpose: re-running setup to change a setting must not
    rebuild a gigabyte of dependencies.
    """
    if plan.venv_python.exists():
        logger.info("Virtualenv already present at %s — reusing it.", plan.venv_dir)
        return
    runner.run([sys.executable, "-m", "venv", plan.venv_dir])


def install_dependencies(plan: DeployPlan, runner: Runner) -> None:
    """Install the project (editable) with whichever optional extras were asked for.

    Editable, because the application locates ``config/`` and ``data/`` relative
    to its own source tree; a copied-into-site-packages install would look for
    them in the wrong place.
    """
    python = plan.venv_python
    runner.run([python, "-m", "pip", "install", "--quiet", "--upgrade", "pip"])
    runner.run(
        [python, "-m", "pip", "install", "--quiet", "-e", _requirement(plan)], cwd=plan.app_dir
    )


def _requirement(plan: DeployPlan) -> str:
    return f".[{','.join(plan.extras)}]" if plan.extras else "."


def initialise_data(plan: DeployPlan, runner: Runner) -> None:
    """Build the service graph once so the metadata database and the encryption
    key exist *before* the first request.

    Left to the first page load, two processes (the app and the scheduler)
    could race to create the key; creating it here, serially, removes that.
    """
    code = "from datarecon.bootstrap import build_container; build_container()"
    runner.run([plan.venv_python, "-c", code], cwd=plan.app_dir)
