# deploy/envfile.py — the ``.env`` the application and the services both read.
from __future__ import annotations

import contextlib
import os
import re
import stat
from collections.abc import Mapping
from pathlib import Path

from deploy.plan import DeployPlan

#: Secrets come from the caller's environment, never from argv (see NotifyOptions).
SECRET_VARIABLES = ("DATARECON_SMTP_PASSWORD", "DATARECON_NOTIFY_WEBHOOK")
_NEEDS_QUOTES = re.compile(r"[\s#'\"$`\\]")


def desired_settings(plan: DeployPlan, environ: Mapping[str, str] | None = None) -> dict[str, str]:
    """The variables this install wants set, omitting anything left blank.

    Blank values are dropped rather than written as ``KEY=`` — an empty
    DATARECON_SMTP_HOST would read as "configured, to nothing", where an absent
    one correctly reads as "not configured".
    """
    environ = os.environ if environ is None else environ
    notify = plan.notify
    values = {
        "DATARECON_SCHEDULE_TZ": plan.timezone,
        "DATARECON_NOTIFY_ON": notify.policy,
        "DATARECON_SMTP_HOST": notify.smtp_host,
        "DATARECON_SMTP_PORT": str(notify.smtp_port) if notify.smtp_host else "",
        "DATARECON_SMTP_USER": notify.smtp_user,
        "DATARECON_NOTIFY_FROM": notify.email_from,
        "DATARECON_NOTIFY_TO": notify.email_to,
    }
    for name in SECRET_VARIABLES:
        values[name] = environ.get(name, "")
    return {key: value for key, value in values.items() if value}


def parse_env(text: str) -> dict[str, str]:
    values: dict[str, str] = {}
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        values[key.strip()] = _unquote(value.strip())
    return values


def render_env(values: Mapping[str, str]) -> str:
    lines = ["# Written by `python -m deploy`. Safe to edit; re-running keeps your changes."]
    lines += [f"{key}={_quote(value)}" for key, value in values.items()]
    return "\n".join(lines) + "\n"


def merge(
    existing: Mapping[str, str], desired: Mapping[str, str], overwrite: bool
) -> dict[str, str]:
    """Combine an existing file with the settings this run wants.

    Existing values win unless ``overwrite`` is set: someone has edited that
    file by hand since the last run, and a setup script that silently reverts
    their SMTP host is a setup script nobody re-runs.
    """
    merged = dict(existing)
    for key, value in desired.items():
        if overwrite or key not in merged:
            merged[key] = value
    return merged


def write_env(
    plan: DeployPlan, overwrite: bool = False, environ: Mapping[str, str] | None = None
) -> list[str]:
    """Write the file and return the keys that changed. Values are never returned."""
    existing = (
        parse_env(plan.env_file.read_text(encoding="utf-8")) if plan.env_file.is_file() else {}
    )
    merged = merge(existing, desired_settings(plan, environ), overwrite)
    changed = sorted(key for key, value in merged.items() if existing.get(key) != value)

    plan.env_file.parent.mkdir(parents=True, exist_ok=True)
    # Create with owner-only permissions *before* any secret is written, rather
    # than writing first and tightening afterwards.
    descriptor = os.open(
        plan.env_file, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, stat.S_IRUSR | stat.S_IWUSR
    )
    with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
        handle.write(render_env(merged))
    _restrict(plan.env_file)
    return changed


def _restrict(path: Path) -> None:
    # Windows ignores POSIX modes; its ACLs are inherited from the folder.
    with contextlib.suppress(OSError):
        path.chmod(stat.S_IRUSR | stat.S_IWUSR)


def _unquote(value: str) -> str:
    if len(value) >= 2 and value[0] == value[-1] == '"':
        return re.sub(r"\\([\\\"])", r"\1", value[1:-1])
    if len(value) >= 2 and value[0] == value[-1] == "'":
        return value[1:-1]
    return value


def _quote(value: str) -> str:
    if not _NEEDS_QUOTES.search(value):
        return value
    escaped = value.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escaped}"'
