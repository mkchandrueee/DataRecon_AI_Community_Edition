import sys

from deploy.cli import main

sys.exit(main())
