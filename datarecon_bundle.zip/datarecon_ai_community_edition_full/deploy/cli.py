# deploy/cli.py — the command line: parse arguments, build a plan, run the steps.
from __future__ import annotations

import argparse
import logging
import sys
from collections.abc import Sequence
from pathlib import Path

from deploy import envfile, environment, health, services
from deploy.plan import (
    DEFAULT_PORT,
    NOTIFY_POLICIES,
    DeployPlan,
    NotifyOptions,
    ServiceScope,
)
from deploy.preflight import Check, blocking, run_preflight
from deploy.runner import CommandError, Runner

logger = logging.getLogger("deploy")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m deploy",
        description="Install and run DataRecon AI Community Edition on a server.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    common = argparse.ArgumentParser(add_help=False)
    common.add_argument(
        "--app-dir", type=Path, default=Path.cwd(), help="Repository root (default: here)."
    )
    common.add_argument(
        "--host", default="127.0.0.1", help="Bind address. Use 0.0.0.0 only behind a proxy."
    )
    common.add_argument("--port", type=int, default=DEFAULT_PORT)
    common.add_argument("--service-name", default="datarecon")
    common.add_argument(
        "--system", action="store_true", help="Install system-wide (needs root/Administrator)."
    )
    common.add_argument(
        "--no-scheduler", action="store_true", help="Do not run the scheduler service."
    )

    sub.add_parser("preflight", parents=[common], help="Check the server is ready; change nothing.")
    sub.add_parser("status", parents=[common], help="Report what is installed and running.")
    sub.add_parser(
        "uninstall", parents=[common], help="Remove the services (keeps data and settings)."
    )

    install = sub.add_parser("install", parents=[common], help="Full setup, start to finish.")
    install.add_argument(
        "--extras",
        nargs="*",
        default=[],
        metavar="GROUP",
        help="Optional dependency groups, e.g. warehouse cloud.",
    )
    install.add_argument(
        "--timezone", default="UTC", help="Zone cron schedules are read in, e.g. Asia/Kolkata."
    )
    install.add_argument("--notify-on", choices=NOTIFY_POLICIES, default="failure")
    install.add_argument("--smtp-host", default="")
    install.add_argument("--smtp-port", type=int, default=587)
    install.add_argument("--smtp-user", default="")
    install.add_argument("--notify-from", default="")
    install.add_argument("--notify-to", default="", help="Comma-separated recipients.")
    install.add_argument(
        "--skip-services", action="store_true", help="Set up the environment but start nothing."
    )
    install.add_argument(
        "--overwrite-env", action="store_true", help="Replace values already in .env."
    )
    install.add_argument(
        "--dry-run", action="store_true", help="Show every step without doing any."
    )
    return parser


def plan_from_args(args: argparse.Namespace) -> DeployPlan:
    notify = NotifyOptions(
        policy=getattr(args, "notify_on", "failure"),
        smtp_host=getattr(args, "smtp_host", ""),
        smtp_port=getattr(args, "smtp_port", 587),
        smtp_user=getattr(args, "smtp_user", ""),
        email_from=getattr(args, "notify_from", ""),
        email_to=getattr(args, "notify_to", ""),
    )
    return DeployPlan(
        app_dir=args.app_dir.resolve(),
        host=args.host,
        port=args.port,
        timezone=getattr(args, "timezone", "UTC"),
        extras=tuple(getattr(args, "extras", ())),
        service_name=args.service_name,
        scope=ServiceScope.SYSTEM if args.system else ServiceScope.USER,
        with_scheduler=not args.no_scheduler,
        notify=notify,
    )


# --------------------------------------------------------------------------- #
# Commands
# --------------------------------------------------------------------------- #
def cmd_preflight(plan: DeployPlan, _args: argparse.Namespace) -> int:
    checks = run_preflight(plan)
    _report(checks)
    return 1 if blocking(checks) else 0


def cmd_status(plan: DeployPlan, _args: argparse.Namespace) -> int:
    checks = health.collect_status(plan)
    _report(checks)
    return 1 if blocking(checks) else 0


def cmd_install(plan: DeployPlan, args: argparse.Namespace) -> int:
    runner = Runner(dry_run=args.dry_run)

    checks = run_preflight(plan)
    _report(checks)
    if blocking(checks):
        logger.error("Fix the failed checks above, then run again.")
        return 1

    logger.info("\n== Environment ==")
    environment.create_virtualenv(plan, runner)
    environment.install_dependencies(plan, runner)

    logger.info("\n== Configuration ==")
    if args.dry_run:
        logger.info("[dry-run] would write %s", plan.env_file)
    else:
        changed = envfile.write_env(plan, overwrite=args.overwrite_env)
        logger.info("Wrote %s (%s)", plan.env_file, ", ".join(changed) or "no changes")
    environment.initialise_data(plan, runner)

    if args.skip_services:
        _print_manual_commands(plan)
        return 0

    logger.info("\n== Services ==")
    services.install_services(plan, runner)

    if args.dry_run:
        return 0
    logger.info("\nWaiting for the application at %s ...", plan.app_url)
    if not health.wait_for_http(plan.health_url):
        logger.error("The application did not answer. Check: %s", _log_hint(plan))
        return 1
    _print_summary(plan)
    return 0


def cmd_uninstall(plan: DeployPlan, _args: argparse.Namespace) -> int:
    services.uninstall_services(plan, Runner())
    logger.info("Services removed. Your data, .env and encryption key were left in place.")
    return 0


_COMMANDS = {
    "preflight": cmd_preflight,
    "status": cmd_status,
    "install": cmd_install,
    "uninstall": cmd_uninstall,
}


# --------------------------------------------------------------------------- #
def _report(checks: Sequence[Check]) -> None:
    for check in checks:
        mark = "ok  " if check.ok else ("FAIL" if check.fatal else "warn")
        logger.info("[%s] %-30s %s", mark, check.name, check.detail)


def _log_hint(plan: DeployPlan) -> str:
    scope = "" if plan.scope is ServiceScope.SYSTEM else "--user "
    return f"journalctl {scope}-u {plan.service_name}-app -n 50"


def _print_manual_commands(plan: DeployPlan) -> None:
    logger.info("\nServices skipped. Start them yourself:")
    for spec in services.build_specs(plan):
        logger.info("  %s", " ".join(spec.argv))


def _print_summary(plan: DeployPlan) -> None:
    logger.info("\nDataRecon is running at %s", plan.app_url)
    if plan.host in {"127.0.0.1", "localhost"}:
        logger.info("It listens on localhost only. Put a reverse proxy in front for remote access.")
    logger.info(
        "Back up %s — losing it means stored connection passwords cannot be recovered.",
        plan.data_dir / ".datarecon.key",
    )
    logger.info("Check anything later with: python -m deploy status")


def main(argv: Sequence[str] | None = None) -> int:
    logging.basicConfig(level=logging.INFO, format="%(message)s", stream=sys.stdout)
    args = build_parser().parse_args(argv)
    plan = plan_from_args(args)
    try:
        return _COMMANDS[args.command](plan, args)
    except CommandError as exc:
        logger.error("%s", exc)
        return 1
    except NotImplementedError as exc:
        logger.error("%s", exc)
        return 1
