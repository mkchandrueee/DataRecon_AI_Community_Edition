# deploy/services.py — run the app and the scheduler as managed services.
#
# Two processes, on purpose (ADR-0014): the web UI only executes code while a
# browser is driving it, so scheduled validations need a process of their own.
from __future__ import annotations

import getpass
import logging
import shlex
import subprocess
from dataclasses import dataclass
from pathlib import Path

from deploy.plan import DeployPlan, OperatingSystem, ServiceScope
from deploy.runner import Runner

logger = logging.getLogger("deploy")


@dataclass(frozen=True)
class ServiceSpec:
    name: str
    description: str
    argv: tuple[str, ...]


def build_specs(plan: DeployPlan) -> list[ServiceSpec]:
    python = str(plan.venv_python)
    specs = [
        ServiceSpec(
            name=f"{plan.service_name}-app",
            description="DataRecon AI web application",
            argv=(
                python,
                "-m",
                "streamlit",
                "run",
                str(plan.app_dir / "app.py"),
                "--server.address",
                plan.host,
                "--server.port",
                str(plan.port),
                "--server.headless",
                "true",
                "--browser.gatherUsageStats",
                "false",
            ),
        )
    ]
    if plan.with_scheduler:
        specs.append(
            ServiceSpec(
                name=f"{plan.service_name}-scheduler",
                description="DataRecon AI scheduled validations",
                argv=(python, "-m", "datarecon.scheduler"),
            )
        )
    return specs


# --------------------------------------------------------------------------- #
# Linux: systemd
# --------------------------------------------------------------------------- #
def render_systemd_unit(spec: ServiceSpec, plan: DeployPlan) -> str:
    wanted_by = "default.target" if plan.scope is ServiceScope.USER else "multi-user.target"
    lines = [
        "[Unit]",
        f"Description={spec.description}",
        "After=network-online.target",
        "Wants=network-online.target",
        "",
        "[Service]",
        "Type=simple",
        f"WorkingDirectory={plan.app_dir}",
        f"EnvironmentFile=-{plan.env_file}",
        f"ExecStart={shlex.join(spec.argv)}",
        "Restart=on-failure",
        "RestartSec=5",
        "NoNewPrivileges=true",
        "",
        "[Install]",
        f"WantedBy={wanted_by}",
        "",
    ]
    return "\n".join(lines)


def unit_directory(plan: DeployPlan) -> Path:
    if plan.scope is ServiceScope.SYSTEM:
        return Path("/etc/systemd/system")
    return Path.home() / ".config" / "systemd" / "user"


def _systemctl(plan: DeployPlan, *args: str) -> list[str]:
    base = ["systemctl"] if plan.scope is ServiceScope.SYSTEM else ["systemctl", "--user"]
    return [*base, *args]


def _install_systemd(plan: DeployPlan, specs: list[ServiceSpec], runner: Runner) -> None:
    directory = unit_directory(plan)
    for spec in specs:
        target = directory / f"{spec.name}.service"
        logger.info("%s %s", "Would write" if runner.dry_run else "Writing", target)
        if not runner.dry_run:
            directory.mkdir(parents=True, exist_ok=True)
            target.write_text(render_systemd_unit(spec, plan), encoding="utf-8")

    runner.run(_systemctl(plan, "daemon-reload"))
    for spec in specs:
        runner.run(_systemctl(plan, "enable", "--now", f"{spec.name}.service"))

    if plan.scope is ServiceScope.USER:
        # A user service stops when its owner logs out unless lingering is on;
        # on a server that is the difference between "running" and "running
        # until the admin disconnects".
        runner.run(["loginctl", "enable-linger", getpass.getuser()], check=False)


def _uninstall_systemd(plan: DeployPlan, specs: list[ServiceSpec], runner: Runner) -> None:
    directory = unit_directory(plan)
    for spec in specs:
        runner.run(_systemctl(plan, "disable", "--now", f"{spec.name}.service"), check=False)
        unit = directory / f"{spec.name}.service"
        if unit.exists() and not runner.dry_run:
            unit.unlink()
    runner.run(_systemctl(plan, "daemon-reload"), check=False)


# --------------------------------------------------------------------------- #
# Windows: Task Scheduler
# --------------------------------------------------------------------------- #
def launcher_path(spec: ServiceSpec, plan: DeployPlan) -> Path:
    return plan.app_dir / "run" / f"{spec.name}.cmd"


def log_path(spec: ServiceSpec, plan: DeployPlan) -> Path:
    return plan.app_dir / "logs" / f"{spec.name}.log"


def render_launcher(spec: ServiceSpec, plan: DeployPlan) -> str:
    """A small batch file that starts one service from the right directory.

    Task Scheduler limits a task's command line to about 260 characters, and the
    install path appears three times in it (working directory, interpreter,
    script) — a long path silently breaks task creation. Pointing the task at a
    launcher keeps the command short whatever the path, and gives Windows what
    systemd gives Linux for free: a log file.
    """
    command = subprocess.list2cmdline(list(spec.argv))
    lines = [
        "@echo off",
        f'cd /d "{plan.app_dir}"',
        f'{command} >> "{log_path(spec, plan)}" 2>&1',
        "",
    ]
    return "\r\n".join(lines)


def _install_windows(plan: DeployPlan, specs: list[ServiceSpec], runner: Runner) -> None:
    for spec in specs:
        launcher = launcher_path(spec, plan)
        logger.info("%s %s", "Would write" if runner.dry_run else "Writing", launcher)
        if not runner.dry_run:
            launcher.parent.mkdir(parents=True, exist_ok=True)
            log_path(spec, plan).parent.mkdir(parents=True, exist_ok=True)
            launcher.write_bytes(render_launcher(spec, plan).encode("utf-8"))

        runner.run(
            [
                "schtasks",
                "/Create",
                "/F",
                "/TN",
                spec.name,
                "/SC",
                "ONSTART",
                "/RU",
                "SYSTEM" if plan.scope is ServiceScope.SYSTEM else getpass.getuser(),
                "/TR",
                f'"{launcher}"',
            ]
        )
        runner.run(["schtasks", "/Run", "/TN", spec.name], check=False)


def _uninstall_windows(plan: DeployPlan, specs: list[ServiceSpec], runner: Runner) -> None:
    for spec in specs:
        runner.run(["schtasks", "/End", "/TN", spec.name], check=False)
        runner.run(["schtasks", "/Delete", "/F", "/TN", spec.name], check=False)


# --------------------------------------------------------------------------- #
def install_services(plan: DeployPlan, runner: Runner) -> None:
    specs = build_specs(plan)
    if plan.os is OperatingSystem.LINUX:
        _install_systemd(plan, specs, runner)
    elif plan.os is OperatingSystem.WINDOWS:
        _install_windows(plan, specs, runner)
    else:
        raise NotImplementedError(
            "Service setup supports Linux (systemd) and Windows (Task Scheduler). "
            "Re-run with --skip-services and start the two commands yourself."
        )


def uninstall_services(plan: DeployPlan, runner: Runner) -> None:
    specs = build_specs(plan)
    if plan.os is OperatingSystem.LINUX:
        _uninstall_systemd(plan, specs, runner)
    elif plan.os is OperatingSystem.WINDOWS:
        _uninstall_windows(plan, specs, runner)
