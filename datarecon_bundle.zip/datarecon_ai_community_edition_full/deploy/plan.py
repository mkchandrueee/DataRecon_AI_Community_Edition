# deploy/plan.py — everything a setup run needs to know, in one immutable place.
from __future__ import annotations

import platform
import sys
import tomllib
from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path

MIN_PYTHON = (3, 11)
#: The project pins numpy==1.26.4, which publishes no wheels for Python 3.13. On a
#: newer interpreter pip fails half-way through the install, after the virtualenv
#: already exists. Raise this when the pin moves.
MAX_PYTHON = (3, 12)
DEFAULT_PORT = 8501
NOTIFY_POLICIES = ("failure", "always", "never")


class OperatingSystem(StrEnum):
    LINUX = "linux"
    WINDOWS = "windows"
    OTHER = "other"

    @classmethod
    def detect(cls) -> OperatingSystem:
        return {"Linux": cls.LINUX, "Windows": cls.WINDOWS}.get(platform.system(), cls.OTHER)


class ServiceScope(StrEnum):
    USER = "user"  # no root needed; survives logout only with lingering enabled
    SYSTEM = "system"  # starts at boot; needs root / Administrator


@dataclass(frozen=True)
class NotifyOptions:
    """Notification settings written to the environment file (ADR-0014).

    Secrets (the SMTP password, the webhook URL) are deliberately absent: they
    are read from the caller's environment, never from argv, where any other
    user on the machine could see them in the process list.
    """

    policy: str = "failure"
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    email_from: str = ""
    email_to: str = ""


@dataclass(frozen=True)
class DeployPlan:
    app_dir: Path
    host: str = "127.0.0.1"
    port: int = DEFAULT_PORT
    timezone: str = "UTC"
    extras: tuple[str, ...] = ()
    service_name: str = "datarecon"
    scope: ServiceScope = ServiceScope.USER
    with_scheduler: bool = True
    notify: NotifyOptions = field(default_factory=NotifyOptions)
    os: OperatingSystem = field(default_factory=OperatingSystem.detect)

    @property
    def venv_dir(self) -> Path:
        return self.app_dir / ".venv"

    @property
    def venv_python(self) -> Path:
        relative = "Scripts/python.exe" if self.os is OperatingSystem.WINDOWS else "bin/python"
        return self.venv_dir / relative

    @property
    def env_file(self) -> Path:
        return self.app_dir / ".env"

    @property
    def data_dir(self) -> Path:
        return self.app_dir / "data"

    @property
    def app_url(self) -> str:
        # A wildcard bind address is not something a client can connect *to*.
        host = "127.0.0.1" if self.host in {"0.0.0.0", "::"} else self.host
        return f"http://{host}:{self.port}"

    @property
    def health_url(self) -> str:
        return f"{self.app_url}/_stcore/health"


def python_supported(version: tuple[int, ...]) -> bool:
    return MIN_PYTHON <= tuple(version[:2]) <= MAX_PYTHON


def current_python_ok() -> bool:
    return python_supported(tuple(sys.version_info))


def available_extras(app_dir: Path) -> frozenset[str]:
    """Optional-dependency groups the project declares, read from pyproject.toml.

    Read rather than hard-coded, so a group added to the project is installable
    here without touching the setup scripts. ``dev`` is excluded: a client
    server has no use for the test toolchain.
    """
    pyproject = app_dir / "pyproject.toml"
    if not pyproject.is_file():
        return frozenset()
    data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
    groups = data.get("project", {}).get("optional-dependencies", {})
    return frozenset(groups) - {"dev"}
