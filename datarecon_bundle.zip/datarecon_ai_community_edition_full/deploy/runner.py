# deploy/runner.py — the one place subprocesses are launched.
from __future__ import annotations

import logging
import shlex
import subprocess
from collections.abc import Mapping, Sequence
from pathlib import Path

logger = logging.getLogger("deploy")


class CommandError(RuntimeError):
    """A command exited non-zero."""

    def __init__(self, argv: Sequence[str], returncode: int):
        self.argv = list(argv)
        self.returncode = returncode
        super().__init__(f"Command failed ({returncode}): {shlex.join(self.argv)}")


class Runner:
    """Runs commands, or only describes them when ``dry_run`` is set.

    Funnelling every subprocess through here is what makes ``--dry-run``
    trustworthy: there is no second code path that could act anyway.
    """

    def __init__(self, dry_run: bool = False):
        self.dry_run = dry_run

    def run(
        self,
        argv: Sequence[str],
        cwd: Path | None = None,
        env: Mapping[str, str] | None = None,
        check: bool = True,
    ) -> int:
        prefix = "[dry-run] " if self.dry_run else "$ "
        logger.info("%s%s", prefix, shlex.join(str(a) for a in argv))
        if self.dry_run:
            return 0
        result = subprocess.run(  # argv is a list, never a shell string
            [str(a) for a in argv], cwd=cwd, env=dict(env) if env else None, check=False
        )
        if check and result.returncode != 0:
            raise CommandError(argv, result.returncode)
        return result.returncode
