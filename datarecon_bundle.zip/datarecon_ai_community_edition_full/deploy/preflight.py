# deploy/preflight.py — find out what is wrong *before* changing anything.
from __future__ import annotations

import importlib.util
import shutil
import socket
import sys
from dataclasses import dataclass
from pathlib import Path

from deploy.plan import MIN_PYTHON, DeployPlan, available_extras, current_python_ok

#: Dependencies include database drivers and columnar engines; installing onto a
#: nearly full disk fails half-way and leaves a broken virtualenv behind.
MIN_FREE_BYTES = 2 * 1024**3
_REQUIRED_PROJECT_FILES = ("pyproject.toml", "app.py")


@dataclass(frozen=True)
class Check:
    name: str
    ok: bool
    detail: str
    #: A failed non-fatal check is a warning: worth saying, not worth stopping.
    fatal: bool = True

    @property
    def blocks(self) -> bool:
        return self.fatal and not self.ok


def run_preflight(plan: DeployPlan) -> list[Check]:
    return [
        _python_version(),
        _venv_support(),
        _project_files(plan.app_dir),
        _extras(plan),
        _writable(plan.app_dir),
        _disk_space(plan.app_dir),
        _port_free(plan),
    ]


def blocking(checks: list[Check]) -> list[Check]:
    return [c for c in checks if c.blocks]


def _python_version() -> Check:
    found = ".".join(str(n) for n in sys.version_info[:3])
    needed = ".".join(str(n) for n in MIN_PYTHON)
    return Check("Python version", current_python_ok(), f"{found} (need {needed}+)")


def _venv_support() -> Check:
    """Debian and Ubuntu ship ``venv`` as a separate package; without it the
    next step fails with an error that does not say what to install."""
    present = importlib.util.find_spec("ensurepip") is not None
    hint = "available" if present else "missing — install python3-venv"
    return Check("venv module", present, hint)


def _project_files(app_dir: Path) -> Check:
    missing = [name for name in _REQUIRED_PROJECT_FILES if not (app_dir / name).is_file()]
    detail = f"missing {', '.join(missing)} in {app_dir}" if missing else f"found in {app_dir}"
    return Check("Project files", not missing, detail)


def _extras(plan: DeployPlan) -> Check:
    unknown = sorted(set(plan.extras) - available_extras(plan.app_dir))
    if unknown:
        offered = ", ".join(sorted(available_extras(plan.app_dir))) or "none"
        return Check(
            "Optional extras", False, f"unknown {', '.join(unknown)} (available: {offered})"
        )
    return Check("Optional extras", True, ", ".join(plan.extras) or "none requested")


def _writable(app_dir: Path) -> Check:
    probe = app_dir if app_dir.exists() else app_dir.parent
    writable = probe.is_dir() and _can_write(probe)
    return Check("Writable install directory", writable, str(app_dir))


def _can_write(directory: Path) -> bool:
    try:
        probe = directory / ".datarecon-write-test"
        probe.touch()
        probe.unlink()
    except OSError:
        return False
    return True


def _disk_space(app_dir: Path) -> Check:
    target = app_dir if app_dir.exists() else app_dir.parent
    free = shutil.disk_usage(target).free
    return Check(
        "Free disk space",
        free >= MIN_FREE_BYTES,
        f"{free / 1024**3:.1f} GB free (want {MIN_FREE_BYTES / 1024**3:.0f} GB+)",
        fatal=False,
    )


def _port_free(plan: DeployPlan) -> Check:
    """A port already in use means either a previous install or something else.

    Reported as a warning: re-running setup over a live install is legitimate,
    and the service restart in a later step handles that case.
    """
    family = socket.AF_INET6 if ":" in plan.host else socket.AF_INET
    with socket.socket(family, socket.SOCK_STREAM) as sock:
        try:
            sock.bind((plan.host, plan.port))
        except OSError as exc:
            return Check("Port available", False, f"{plan.host}:{plan.port} — {exc}", fatal=False)
    return Check("Port available", True, f"{plan.host}:{plan.port}")
