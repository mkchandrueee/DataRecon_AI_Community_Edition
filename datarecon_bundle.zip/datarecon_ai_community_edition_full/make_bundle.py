"""Zip the DataRecon project for copying to a server.

Run from the project root:   python make_bundle.py
Writes ../datarecon_bundle.zip. Leaves out everything that must not travel:
your local virtualenv, git history, test data/keys, and secrets.
"""

from __future__ import annotations

import sys
import zipfile
from pathlib import Path

ROOT = Path.cwd()
OUTPUT = ROOT.parent / "datarecon_bundle.zip"

# Folders and files that must NOT be copied to the server.
EXCLUDED_DIRS = {
    ".venv", "venv", ".git", ".idea", ".vscode", "__pycache__", ".pytest_cache",
    ".ruff_cache", ".mypy_cache", "node_modules",
}
# Only skipped at the project root: runtime data, logs and service launchers.
# A source folder that happens to be called "data" deeper down must still travel.
EXCLUDED_ROOT_DIRS = {"data", "logs", "run"}
EXCLUDED_FILES = {".env", "coverage.xml", ".coverage"}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".log"}
EXCLUDED_DIR_SUFFIXES = (".egg-info",)

# One check per delivered feature batch: a file that must exist and, where the
# file already existed before the batch, a piece of text only the batch adds.
# If any check fails, this copy of the project is incomplete.
REQUIRED = {
    "the project itself": [("app.py", None), ("pyproject.toml", None)],
    "batch 1  (summary tables, reports)": [
        ("datarecon/presentation/components/summary_table.py", None)
    ],
    "batch 2  (AI Generate SQL / Bulk Setup)": [
        ("datarecon/application/services/sql_generation_service.py", None)
    ],
    "batch 3  (Referential Integrity)": [
        ("datarecon/application/services/referential_integrity_service.py", None)
    ],
    "batch 4  (Test Suites bulk actions)": [
        ("datarecon/presentation/views/test_suites_view.py", "_render_bulk_actions")
    ],
    "batch 5  (batched extracts)": [
        ("datarecon/presentation/components/report_export.py", "render_detail_csv_downloads")
    ],
    "batch 6  (scheduling + notifications)": [
        ("datarecon/bootstrap.py", None),
        ("datarecon/scheduler.py", None),
        ("datarecon/core/cron.py", None),
    ],
    "batch 7  (mismatch insights)": [("datarecon/core/mismatch_patterns.py", None)],
    "batch 8  (Reports bulk actions)": [
        ("datarecon/application/services/run_management_service.py", None)
    ],
    "batch 10 (server setup scripts)": [("deploy/cli.py", None), ("deploy/services.py", None)],
}


def is_excluded(path: Path) -> bool:
    parts = path.relative_to(ROOT).parts
    if len(parts) > 1 and parts[0] in EXCLUDED_ROOT_DIRS:
        return True
    if any(part in EXCLUDED_DIRS or part.endswith(EXCLUDED_DIR_SUFFIXES) for part in parts[:-1]):
        return True
    name = path.name
    return name in EXCLUDED_FILES or path.suffix in EXCLUDED_SUFFIXES


def check_present(relative: str, needle: str | None) -> bool:
    path = ROOT / relative
    if not path.is_file():
        return False
    return needle is None or needle in path.read_text(encoding="utf-8", errors="ignore")


def missing_features() -> dict[str, list[str]]:
    gaps = {}
    for feature, checks in REQUIRED.items():
        absent = [
            f"{relative}" + (f"  (should contain {needle})" if needle else "")
            for relative, needle in checks
            if not check_present(relative, needle)
        ]
        if absent:
            gaps[feature] = absent
    return gaps


def main() -> int:
    print(f"Project folder: {ROOT}")
    gaps = missing_features()
    if gaps:
        print("\nThis copy of the project is INCOMPLETE. Missing:")
        for feature, files in gaps.items():
            print(f"  - {feature}")
            for f in files:
                print(f"      {f}")
        print("\nApply the missing patches (git am -3 <patch>) and run this again.")
        return 1

    files = sorted(p for p in ROOT.rglob("*") if p.is_file() and not is_excluded(p))
    with zipfile.ZipFile(OUTPUT, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            archive.write(path, Path(ROOT.name) / path.relative_to(ROOT))

    size_mb = OUTPUT.stat().st_size / 1_048_576
    print(f"\nAll features present. Packed {len(files)} files ({size_mb:.1f} MB):")
    print(f"  {OUTPUT}")
    print(f"\nCopy that zip to the server and unzip it. You get a folder named '{ROOT.name}';")
    print("rename or move it to C:\\DataRecon, then follow the install steps.")
    return 0


if __name__ == "__main__":
    sys.exit(main())